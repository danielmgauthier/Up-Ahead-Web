# About me

Hey there! 👋

I'm Dan. I'm an iOS developer from Ottawa, Canada, I've been doing it professionally for about a decade, and recently, in my limited free time, I've been designing and building independent apps. 

These are primarily creative projects for me, and Up Ahead in particular has really been a vehicle for me to push my ideas about app design as far as they'll go. My apps are functionally simple, but my goal is to polish the heck out of them and build apps that are truly playful and fun to use. 

Up Ahead is the second app I've released over the past few years; the first was Oh Bother, in 2020, which you can learn more about at at [https://ohbother.app](https://ohbother.app). Oh Bother was well-received, and it was promoted by Apple on both the App Store and on social media.  

You can find out a bit more about me on [my website](https://danielgauthier.me), though it has now been a couple years since I've written anything there — I've been busy raising a toddler and building Up Ahead!

If you have any questions at all, feel free to reach out at danielgauthier.dev@gmail.com
