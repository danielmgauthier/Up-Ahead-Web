# About the app

Up Ahead is a playful, beautiful way to keep track of everything you’re looking forward to. Create events in seconds, and build yourself an eclectic timeline full of birthdays, weddings, holidays, vacations, game releases, sporting events, or anything coming up that brings you joy. As your timeline grows, you’ll unlock themed patterns that can be used to give your events personality. Keep your countdowns top of mind with customizable widgets for your Home Screen or Lock Screen.

